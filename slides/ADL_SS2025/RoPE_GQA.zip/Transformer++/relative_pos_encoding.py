# %% [markdown]
## Positional Encoding
# [Umar Jamil](https://www.youtube.com/watch?v=Mn_9W1nCFLo)
#
# We have learned about two types of positional encoding:
#- Sinusoidal positional encoding
#- Learned positional encoding
#- For both methods, an encoding that depends on the absolute position of the token in the sequence is applied.
#- Problem: We do not take into account relative distance between tokens. 
#
# %% [markdown]
#### Vanilla Attention:
# $$\frac{(x_i W^Q)(x_j W^K)^\top}{\sqrt{d}}$$
# Absolute positional encodings are reflected in the features $x_i$ and $x_j$.

# %% [markdown]
#### Attention with relative positional encodings:
# $$\frac{(x_i W^Q)(x_j W^K + a_{ij})^\top}{\sqrt{d}}$$
#- Vector $a_{ij}$ can depend on the distance $i-j$.
#- How exactly to choose $a_{ij}$ exactly?
#  - $a_{ij} = w_{\text{clip}(j-i,k)}$
#    - Clip beyond a distance threshold.
#- Proposed in [Self-Attention with Relative Position Representation](https://arxiv.org/abs/1803.02155)

# %% [markdown]
#### Rotary Positional Embeddings
#- Let $n$ and $m$ be two positions and $x_n$ and $x_m$ the features at the respective position
#- Queries and keys are computed as
#  - $q_m = f_q(x_m,m)$
#  - $k_n = f_k(x_n,n)$
#- Inner product becomes $$ q_m^\top k_n = \langle f_q(x_m,m), f_k(x_n,n) \rangle = g(x_m, x_n, n-m)$$
#  - Design $f_q, f_k$ and $g$ such that the above relations can hold.
#- Rotary Position Embeddings Single Complex Case:
#  - Assume complex numbers $x_m, x_n, W_q, W_k \in \mathbb{C}$
#  - $f_q(x_m,m) = (W_q x_m) e^{im\theta}$
#  - $f_k(x_n,n) = (W_k x_n) e^{in\theta}$
#  - $g(x_m, x_n, n-m) = \text{Re}[(W_q x_m) (W_k x_n)^* e^{i(m-n) \theta}]$
#    - $(\cdot)^*$ is the conjugate of a complex number
#- Euler's formula:
# $$ f_{\{q,k\}}(x_m,m) = \begin{pmatrix} \cos m\theta & -\sin m\theta \\ \sin m\theta & \cos m\theta \end{pmatrix} \begin{pmatrix} (W_{\{q,k\}})_{11} & (W_{\{q,k\}})_{12} \\ (W_{\{q,k\}})_{21} & (W_{\{q,k\}})_{22} \end{pmatrix} \begin{pmatrix} (x_m)_1 \\ (x_m)_2 \end{pmatrix} $$
#- Rotary Position Embedding: General case
#  - $x_m, x_n \in \R^{2d}$.
#  - $f_{\{q,k\}}(x_m,m) = R_{\Theta,m}^d W_{\{q,k\}} x_m$
#$$
#R_{\Theta,m} =
#\begin{pmatrix}
#\cos(m\theta_1) & -\sin(m\theta_1) & 0 & 0 & \cdots & 0 & 0 \\
#\sin(m\theta_1) &  \cos(m\theta_1) & 0 & 0 & \cdots & 0 & 0 \\
#0 & 0 & \cos(m\theta_2) & -\sin(m\theta_2) & \cdots & 0 & 0 \\
#0 & 0 & \sin(m\theta_2) &  \cos(m\theta_2) & \cdots & 0 & 0 \\
#\vdots & \vdots & \vdots & \vdots & \ddots & \vdots & \vdots \\
#0 & 0 & 0 & 0 & \cdots & \cos(m\theta_{d/2}) & -\sin(m\theta_{d/2}) \\
#0 & 0 & 0 & 0 & \cdots & \sin(m\theta_{d/2}) &  \cos(m\theta_{d/2})
#\end{pmatrix}
#$$
#  - We take $\Theta = \{\theta_i = 10.000^{-2(i-1)/d}, i \in [1,2,\ldots,d/2]\}$
#  - Applying RoPE yields
# $$q_m^{\top} k_n = (R_{\theta,m}^d W_q x_m)^{\top} (R_{\Theta n}^d W_k x_n) = x^{\top} W_q R_{\Theta, n-m}^d W_k x_n$$
#
#- Proposed in [RoFormer: Enhanced Transformer with Rotary Position Embedding](https://arxiv.org/abs/2104.09864)

# %% [markdown]
#### Computational Realization
#- Multiplying naively with matrix $R_{\Theta,m} x$ is not efficient.
#- Instead do implementation with two pointwise vector multiplications
#$$
#\mathbf{R}^d_{\Theta, m} \bm{x} =
#\begin{pmatrix}
#x_1 \\
#x_2 \\
#x_3 \\
#x_4 \\
#\vdots \\
#x_{d-1} \\
#x_d
#\end{pmatrix}
#\odot
#\begin{pmatrix}
#\cos(m\theta_1) \\
#\cos(m\theta_1) \\
#\cos(m\theta_2) \\
#\cos(m\theta_2) \\
#\vdots \\
#\cos(m\theta_{d/2}) \\
#\cos(m\theta_{d/2})
#\end{pmatrix}
#+
#\begin{pmatrix}
#-x_2 \\
#x_1 \\
#-x_4 \\
#x_3 \\
#\vdots \\
#-x_d \\
#x_{d-1}
#\end{pmatrix}
#\odot
#\begin{pmatrix}
#\sin(m\theta_1) \\
#\sin(m\theta_1) \\
#\sin(m\theta_2) \\
#\sin(m\theta_2) \\
#\vdots \\
#\sin(m\theta_{d/2}) \\
#\sin(m\theta_{d/2})
#\end{pmatrix}
#$$

# %% 
# Rotary Position Embeddings Implementation
import torch

def precompute_theta_pos_frequencies(head_dim: int, seq_len: int, device: str, theta: float = 10000.0):
    # As written in the paragraph 3.2.2 of the paper
    # >> In order to generalize our results in 2D to any xi ∈ Rd where **d is even**, [...]
    assert head_dim % 2 == 0, "Dimension must be divisible by 2"
    # Build the theta parameter
    # According to the formula theta_i = 10000^(-2(i-1)/dim) for i = [1, 2, ... dim/2]
    # Shape: (Head_Dim / 2)
    theta_numerator = torch.arange(0, head_dim, 2).float()
    # Shape: (Head_Dim / 2)
    theta = 1.0 / (theta ** (theta_numerator / head_dim)).to(device) # (Dim / 2)
    # Construct the positions (the "m" parameter)
    # Shape: (Seq_Len)
    m = torch.arange(seq_len, device=device)
    # Multiply each theta by each position using the outer product.
    # Shape: (Seq_Len) outer_product (Head_Dim / 2) -> (Seq_Len, Head_Dim / 2)
    freqs = torch.outer(m, theta).float()
    # We can compute complex numbers in the polar form c = R * exp(m * theta), where R = 1 as follows:
    # (Seq_Len, Head_Dim / 2) -> (Seq_Len, Head_Dim / 2)
    freqs_complex = torch.polar(torch.ones_like(freqs), freqs)
    return freqs_complex

def apply_rotary_embeddings(x: torch.Tensor, freqs_complex: torch.Tensor, device: str):
    # Separate the last dimension pairs of two values, representing the real and imaginary parts of the complex number
    # Two consecutive values will become a single complex number
    # (B, Seq_Len, H, Head_Dim) -> (B, Seq_Len, H, Head_Dim/2)
    x_complex = torch.view_as_complex(x.float().reshape(*x.shape[:-1], -1, 2))
    # Reshape the freqs_complex tensor to match the shape of the x_complex tensor. So we need to add the batch dimension and the head dimension
    # (Seq_Len, Head_Dim/2) --> (1, Seq_Len, 1, Head_Dim/2)
    freqs_complex = freqs_complex.unsqueeze(0).unsqueeze(2)
    # Multiply each complex number in the x_complex tensor by the corresponding complex number in the freqs_complex tensor
    # Which results in the rotation of the complex number as shown in the Figure 1 of the paper
    # (B, Seq_Len, H, Head_Dim/2) * (1, Seq_Len, 1, Head_Dim/2) = (B, Seq_Len, H, Head_Dim/2)
    x_rotated = x_complex * freqs_complex
    # Convert the complex number back to the real number
    # (B, Seq_Len, H, Head_Dim/2) -> (B, Seq_Len, H, Head_Dim/2, 2)
    x_out = torch.view_as_real(x_rotated)
    # (B, Seq_Len, H, Head_Dim/2, 2) -> (B, Seq_Len, H, Head_Dim)
    x_out = x_out.reshape(*x.shape)
    return x_out.type_as(x).to(device)
import matplotlib as plt

# %%
# Apply 
import math
import matplotlib.pyplot as plt
import torch.nn.functional as F
import numpy as np

d = 32
max_seq_len = 1024
seq_len = 100
freqs_complex = precompute_theta_pos_frequencies(d, max_seq_len * 2, 'cpu')

# (B, seq_len, num_heads, head_dim)
xq = torch.randn(1,seq_len,1,d)
xk = torch.randn(1,seq_len,1,d)
xq = apply_rotary_embeddings(xq, freqs_complex[0:seq_len], device='cpu')
xk = apply_rotary_embeddings(xq, freqs_complex[0:seq_len], device='cpu')

# (B, seq_len, num_heads, head_dim) -> (B, num_heads, seq_len, head_dim)
xq = xq.transpose(1, 2)
xk = xk.transpose(1, 2)
scores = torch.matmul(xq, xk.transpose(2,3)) / math.sqrt(d)

scores_np = scores[0, 0, :, :].detach().cpu().numpy()

plt.imshow(scores_np, cmap='viridis', aspect='auto')
plt.colorbar()
plt.title("Attention Scores")
plt.xlabel("Key Positions")
plt.ylabel("Query Positions")
plt.show()

#After softmax
att_w = F.softmax(scores[0,0,:,:], dim=-1)
att_w_np = att_w.detach().cpu().numpy()

plt.imshow(att_w, cmap='viridis', aspect='auto')
plt.colorbar()
plt.title("Attention weights")
plt.xlabel("Key Positions")
plt.ylabel("Query Positions")
plt.show()

# attention scores tend to decay with length
x = np.linspace(0,1,seq_len)
for i in range(10):
    plt.plot(x, att_w_np[:,i*10], label=f'attention weights token {i*10}')
plt.legend()
plt.show()

# %% [markdown]
#### Long-Term Decay of RoPE
# Write 
#$$
#\underbrace{\left( R_{\Theta, m}^d W_q x_m \right)^\top}_{=q} \underbrace{\left( R_{\Theta, n}^d W_k x_n \right)}_{=k}
#= \mathrm{Re} \left[ \sum_{i=0}^{d/2 - 1} \mathbf{q}_{[2i:2i+1]} \mathbf{k}^*_{[2i:2i+1]} e^{i(m-n)\theta_i} \right]
#$$
# This can be rewritten as
#$$
#\sum_{i=0}^{d/2 - 1} \mathbf{q}_{[2i:2i+1]} \mathbf{k}^*_{[2i:2i+1]} e^{i (m - n) \theta_i}
#= \sum_{i=0}^{d/2 - 1} h_i (S_{i+1} - S_i)
#= - \sum_{i=0}^{d/2 - 1} S_{i+1} (h_{i+1} - h_i).
#$$
#Denote
#$$ 
#h_i = \mathbf{q}_{[2i:2i+1]} \mathbf{k}^*_{[2i:2i+1]}
#$$
#and
#$$
#S_j = \sum_{i=0}^{j-1} e^{i(m-n)\theta_i}
#$$
#
#We can estimate an upper bound by
#$$
#\left| \sum_{i=0}^{d/2 - 1} \mathbf{q}_{[2i:2i+1]} \mathbf{k}^*_{[2i:2i+1]} e^{i(m-n)\theta_i} \right|
#= \left| \sum_{i=0}^{d/2 - 1} S_{i+1}(h_{i+1} - h_i) \right|
#\leq \sum_{i=0}^{d/2 - 1} |S_{i+1}|\,|h_{i+1} - h_i|
#\leq \left( \max_i |h_{i+1} - h_i| \right) \sum_{i=0}^{d/2 - 1} |S_{i+1}|
#$$
#
#Note that $|S_j|$ decays with the absolute distance
#<img src="./Transformer++/rope_decay.png" width="600"/>

# %% [markdown]
#### Summary
#- Absolute Positional Encodings
#  - Applied once on the input embeddings
#  - Dependent on the absolute position in the sequence
#- Relative Positional Encoding
#  - Applied for every attention operation
#  - Dependent upon relative distance between tokens
#  - Can be factorized and applied into each token before attention
