# %% [markdown]
## General Considerations for Speeding up NNs
#- GPUs have high arithmetic speed and (comparatively) low memory bandwidth
#  - Recomputing stuff might be faster than storing in memory
#  - Reducing memory movements will pay off
#- General idea: Computing N different operations on a *single* tensor might be faster than computing N different operations on *different* tensors

# %% [markdown]
#### Multi-Query Attention
#- Apply above ideas to attention computation:
#  - Compute attention from different queries but *same* keys and values
#  - Will not help much in training (is not memory bound for keys and values computation) and we have FlashAttention to minimize memory transfers
#  - But will help in inference with KV-cache

# %%
# Vanilla MHA
import torch

def MultiheadAttentionBatched():
    d_model, seq_len_kv, seq_len, b, h, d_k, d_v = 512, 10, 10, 32, 8, (512 // 8), (512 // 8)

    X = torch.rand(b, seq_len, d_model)  # Query
    M = torch.rand(b, seq_len_kv, d_model)  # Key and Value
    mask = torch.rand(b, h, seq_len, seq_len_kv)
    P_q = torch.rand(h, d_model, d_k)  # W_q
    P_k = torch.rand(h, d_model, d_k)  # W_k
    P_v = torch.rand(h, d_model, d_v)  # W_v
    P_o = torch.rand(h, d_model, d_v)  # W_o
    
    Q = torch.einsum("bnd,hdk->bhnk ", X, P_q) 
    K = torch.einsum("bmd,hdk->bhmk", M, P_k)
    V = torch.einsum("bmd,hdv->bhmv", M, P_v)

    logits = torch.einsum("bhnk,bhmk->bhnm", Q, K)
    weights = torch.softmax(logits + mask, dim=-1)

    O = torch.einsum("bhnm,bhmv->bhnv ", weights, V)
    Y = torch.einsum("bhnv,hdv->bnd ", O, P_o)
    return Y

# %%
# Incremental MHA with KV-cache
# For use in inference
def MultiheadSelfAttentionIncremental():
    d_model, b, h, d_k, d_v = 512, 32, 8, (512 // 8), (512 // 8)

    m = 5  # Suppose we have already cached "m" tokens
    prev_K = torch.rand(b, h, m, d_k)
    prev_V = torch.rand(b, h, m, d_v)

    X = torch.rand(b, d_model)  # Query
    M = torch.rand(b, d_model)  # Key and Value
    P_q = torch.rand(h, d_model, d_k)  # W_q
    P_k = torch.rand(h, d_model, d_k)  # W_k
    P_v = torch.rand(h, d_model, d_v)  # W_v
    P_o = torch.rand(h, d_model, d_v)  # W_o

    q = torch.einsum("bd,hdk->bhk", X, P_q)
    new_K = torch.concat(
        [prev_K, torch.einsum("bd,hdk->bhk", M, P_k).unsqueeze(2)], axis=2
    )
    new_V = torch.concat(
        [prev_V, torch.einsum("bd,hdv->bhv", M, P_v).unsqueeze(2)], axis=2
    )
    logits = torch.einsum("bhk,bhmk->bhm", q, new_K)
    weights = torch.softmax(logits, dim=-1)
    O = torch.einsum("bhm,bhmv->bhv", weights, new_V)
    y = torch.einsum("bhv,hdv->bd", O, P_o)
    return y, new_K, new_V

# %% [markdown]
#- Number of arithmetic operations: $O(bnd^2)$
#- Memory involved: $O(bn^2d + nd^2)$
#- Ratio between memory and arithmetic: $O(n/d + 1/b)$
#  - For sequence length $n$ large enough the memory accesses become bottlenecks

# %% [markdown]
#### Multi-Query Attention
# Idea: 
#- Remove different values for $K$ and $V$ of different heads
#- Keep different values for $Q$ for different heads

# %%
# MQA with KV-cache
def MultiquerySelfAttentionIncremental():
    d, b, h, k, v = 512, 32, 8, (512 // 8), (512 // 8)

    m = 5  # Suppose we have already cached "m" tokens
    prev_K = torch.rand(b, m, k)
    prev_V = torch.rand(b, m, v)

    X = torch.rand(b, d)  # Query
    M = torch.rand(b, d)  # Key and Value
    P_q = torch.rand(h, d, k)  # W_q
    P_k = torch.rand(d, k)  # W_k
    P_v = torch.rand(d, v)  # W_v
    P_o = torch.rand(h, d, v)  # W_o

    q = torch.einsum("bd,hdk->bhk", X, P_q)
    K = torch.concat([prev_K, torch.einsum("bd,dk->bk", M, P_k).unsqueeze(1)], axis=1)
    V = torch.concat([prev_V, torch.einsum("bd,dv->bv", M, P_v).unsqueeze(1)], axis=1)
    logits = torch.einsum("bhk,bmk->bhm", q, K)
    weights = torch.softmax(logits, dim=-1)
    O = torch.einsum("bhm,bmv->bhv", weights, V)
    y = torch.einsum("bhv,hdv->bd", O, P_o)
    return y, K, V

# %% [markdown]
#- Number of arithmetic operations: $O(bnd^2)$
#- Memory involved: $O(bnd + bn^2k + nd^2)$
#- Ratio between memory and arithmetic: $O(1/d + n/(dh) + 1/b)$
#  - We have reduced the expensive term $n/d$ by a factor of $h$.
#- In practice we get some performance degradation.
#  - Still worth it due to efficiency gain.
#  - Can instead invest in bigger model to make up degradation and still be faster
#- Paper: [Fast Transformer Decoding: One Write-Head is All You Need](https://arxiv.org/abs/1911.02150)

# %% [markdown]
#### Grouped Multi-Query Attention: Between MHA and MQA
#- Use multiple groups of queries
#  - For one group we get MQA
#  - For $h$ groups we get MHA
#
#<img src="./Transformer++/gqa.png" width="600"/>

# %%
def GroupedMultiquerySelfAttentionIncremental():
    d, b, h, g, k, v = 512, 32, 8, (8 // 2), (512 // 8), (512 // 8)

    m = 5  # Suppose we have already cached "m" tokens
    prev_K = torch.rand(b, g, m, k)
    prev_V = torch.rand(b, g, m, v)

    X = torch.rand(b, d)  # Query
    M = torch.rand(b, d)  # Key and Value
    P_q = torch.rand(h, d, k)  # W_q
    P_k = torch.rand(g, d, k)  # W_k
    P_v = torch.rand(g, d, v)  # W_v
    P_o = torch.rand(h, d, v)  # W_o

    q = torch.einsum("bd,hdk->bhk", X, P_q)
    K = torch.concat([prev_K, torch.einsum("bd,gdk->bgk", M, P_k).unsqueeze(1)], axis=1)
    V = torch.concat([prev_V, torch.einsum("bd,gdv->bgv", M, P_v).unsqueeze(1)], axis=1)
    group_map = torch.arange(h) // (h // g)
    K_expanded = K[group_map]
    V_expanded = V[group_map]
    logits = torch.einsum("bhk,hbmk->bhm", q, K)
    weights = torch.softmax(logits, dim=-1)
    O = torch.einsum("bhm,hbmv->bhv", weights, V)
    y = torch.einsum("bhv,hdv->bd", O, P_o)
    return y, K, V

# %%
if __name__ == "__main__":
    MultiheadAttentionBatched()
    MultiheadSelfAttentionIncremental()
    MultiquerySelfAttentionIncremental()
    GroupedMultiquerySelfAttentionIncremental()