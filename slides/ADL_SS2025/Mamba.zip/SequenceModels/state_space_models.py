# %% [markdown]
## Sequence Models
# Image ack: Maarten Grootendorst
#- Recurrent neural networks and LSTMs are slow during training:
#  - Autoregressive loop unrolled during training.
#  - One token is processed at a time, sequentially.
#- Attention: Autoregressive generation but parallel training.
#  - much faster training!
#
# State space models (SSMs) are a new class of sequence models that can be trained in parallel.
#  - One of the other fundamental models worth knowing.
#  - I think some contemporary LLMs might be striped Transformers that interleave SSMs and attention.

# %% [markdown]
### State Space Models Origins
# SSMs come from ordinary differential equations (ODEs).
#- Variables:
#  - Input $x(t) \in \R$ is a function of time.
#  - Maps to a latent state representation $h(t)$.
#  - Derive a predicted output sequence $y(t)$.
#- State equation: $h'(t) = A h(t) + B x(t)$
#
#<img src="./SequenceModels/ssm_state_equation.png" width="600"/>
#
#- Output equation: $y(t) = C h(t) + D x(t)$
#
#<img src="./SequenceModels/ssm_output_equation.png" width="600"/>
#
#- Overall system:
#
#<img src="./SequenceModels/ssm_equations_diagram_detail.png" width="600"/>

# %% [markdown]
### Solution of Continuous SSM
#- Consider $h'(t) = A\,h(t) + B\,x(t)$
#  - Initial condition $h(0) = h_0$
##### Homogeneous Solution
#- First, we derive the solution for $h'(t) = A\,h(t)$.
#$$
# h'(t) = A h(t) 
# \Rightarrow
# \int_{0}^{t} \frac{h'(t)}{h(t)} dt = \int_{0}^{t} A dt
#$$
#$$
# \Rightarrow \log(h(t)) - \log(h(0)) = t A 
# \Rightarrow h(t) = h(0) \exp(t A)
#$$
#    - Note that this holds true when using matrices and matrix exponentials as well.
##### Inhomogeneous Solution
#- Now consider the case $h'(t) = A\, h(t) + b\, x(t)$
#  - Bring $h$ to the left side and multiply with $\exp(-A t)$
#$$e^{-A t}\dot{h}(t) - e^{-A t}A\,h(t) = e^{-A t}B\,x(t)$$
#  - The left side is the derivative of $e^{-A t}h(t)$
#    - Use the product rule: $\frac{d}{dt}(e^{-A t}h) = e^{-A t}\dot{h} - A e^{-A t}h$
#  - We have $\frac{d}{dt}\!\Big(e^{-A t}\,h(t)\Big) = e^{-A t}\,B\,x(t)$
#  - Integrate both sides
#$$e^{-A t}\,h(t) - e^{-A t_0}\,h(t_0) \;=\; \int_{t_0}^{\,t} e^{-A \tau}\,B\,x(\tau)\,d\tau$$
#  - Rearrange and multiply with $\exp(A t)$:
#$$h(t) \;=\; e^{A (t - t_0)}\,h(t_0) \;+\; \int_{t_0}^{\,t} e^{A (t - \tau)}\,B\,x(\tau)\,d\tau$$

# %% [markdown]
### From Continuous to Discrete 
#
#- We need to discretize the equations to use them in sequence modelling.
#- We will use the Zero-order hold technique: 
#  - Introduce a discrete step size $\Delta$ (this is how long we hold the signal)
#
#<img src="./SequenceModels/ssm_sequence_discretization.png" width="600"/>
#
#- Apply solution above to one interval $[k \cdot \Delta, (k+1) \cdot \Delta]$:
#\begin{aligned}
#h((k+1)\Delta) &= e^{A((k+1)\Delta - k\Delta)}\,h(k\Delta)\;+\; \int_{k\Delta}^{(k+1)\Delta} e^{A((k+1)\Delta - \tau)}\,B\,x(\tau)\,d\tau, \\
#&= e^{A\Delta}\,h_k \;+\; \int_{k\Delta}^{(k+1)\Delta} e^{A((k+1)\Delta - \tau)}\,B\,x_k\,d\tau,
#\end{aligned}
#
#- We can push $x_k$ outside the integral, since it is constant. Also change integration interval from $[k \cdot \Delta, (k+1)\cdot\Delta]$ to $[0,\Delta]$.
#
#$$h((k+1)\Delta) = e^{A\Delta}\,h_k + \left(\int_{0}^{\Delta} e^{A u}\,du\right) B\, x_k$$
#
#- Discretized matrix $\bar{A} = \exp(\Delta A)$.
#- Discretized matrix $\bar{B} = \int_{0}^{\Delta} e^{A u}\,du \; B$
#  - Closed form expression:
#    - Differentiating $e^{A u}$ with respect to $u$ gives $A e^{A u}$. 
#    - Integrating from both sides gives $e^{A\Delta} - I = \int_{0}^{\Delta} A e^{A u} du = A \int_{0}^{\Delta} e^{A u} du$
#    - Therefore $A \left(\int_{0}^{\Delta} e^{A u}\,du\right) = e^{A\Delta} - I \;\;\implies\;\; \int_{0}^{\Delta} e^{A u}\,du = A^{-1}\big(e^{A\Delta} - I\big)$

#  - Discretized matrix $\bar{B} = (\Delta A)^{-1} (\exp(\Delta A) - \text{Id}) \Delta B$
#- The state equation becomes: 
#  - $h_k = \bar{A} h_{k-1} + \bar{B} x_k$
#  - $y_k = C h_k + D x_k$
#    - During training, we hold parameters of $A$, not $\bar{A}$, and exponentiate on demand.

# %% [markdown]
#### Recurrent Representation
#
#<img src="./SequenceModels/ssm_as_rnn.png" width="600"/>
#
# Unroll:
#
#<img src="./SequenceModels/ssm_as_rnn_unrolled.png" width="600"/>
#

# %% [markdown]
#### Convolutional Solution
# We can solve the SSM above via convolution with a special kernel.
#- Define the following kernel
#
#<img src="./SequenceModels/ssm_kernel.png" width="600"/>
#
#- If we apply this kernel, we get
#
#<img src="./SequenceModels/ssm_kernel_application1.png" width="600"/>
#
#<img src="./SequenceModels/ssm_kernel_application2.png" width="600"/>

# %% [markdown]
#### Three representations:
#
# We have three representations:
#
#<img src="./SequenceModels/ssm_representations.png" width="600"/>
#
#- Use recurrent for inference
#- Use convolutional for training (can be parallelized)

# %% [markdown]
#### Design of $A$
#- Determines how hidden state is updated
#  - Should allow to selectively remember/forget past information
#  - And make place for putting in new information
#- The [HiPPO paper](https://arxiv.org/abs/2008.07669) proposed 
#
#<img src="./SequenceModels/ssm_hippo_matrix.png" width="600"/>
#
#  - $4 \times 4$ example:
#
#<img src="./SequenceModels/ssm_hippo_matrix_4x4.png" width="600"/>
#
#  - Compresses old information and incorporates new one.
#  - Much better than initializing $A$ randomly and training it.

# %% [markdown]
### Mamba
##### Selective State Space
#- Above we have designed a **Linear Time Invariant** (LTI) system.
#  - Neither $A$, $\Delta$, $B$, $C$ or $D$ vary with time.
#  - Allows for convolutional representation and fast training
#  - Is not very expressive 
#    - Update equations are not content-aware
#- Mamba improves upon LTI while still allowing for fast training.
#  - Make $\Delta_t$, $B_t$ and $C_t$ time dependent
#    - Smaller $\Delta_t$ results in ignoring current input and using previous state
#    - Larger $\Delta_t$ results in ignoring previous hidden state and using current input
#  - **Parallel scan algorithm** for fast parallel training

# %% [markdown]
#### Scan Operation
#- Let us look into how to implement the parallel scan algorithm for an associative operation:
#  - Take sum $\Sigma$ as example.
#    - But works on any associative operation, useful for Mamba later.
#  - We want to compute $\Sigma_{i=0}^t x_i$ for all $t=0,\ldots,T$ using parallelism.
#    - Sequential algorithm takes $O(T)$ time.
#  - Naive parallel implementation
#    - Compute $x_{0:1} = x_0 + x_1$, $x_{1:2} = x_1 + x_2$, $\ldots$, $x_{T-1:t} = x_{T-1}, x_T$ in parallel
#    - Compute $x_{0:2} = x_0 + x_{1:2}, $x_{0:3} = x_{0:1} + x_{2:3}$, $x_{1:4} = x_{1:2} + x_{2:3}$, $\ldots, $x_{T-3:T} = x_{T-3:T-2} + x_{T-1:T}$ in parallel
#    - ...
#    - Compute $x_{0:T/2+1} = x_0 + x_{1:T/2+1}$, $\ldots$, $x_{0:T} = x_{0:T/2} + x_{T/2+1:T}$
#    - Logarithmic number of outer steps.
#    - But every level performs $O(T)$ operations in parallel.
#
#<img src="./SequenceModels/naive_parallel_scan.png" width="600"/>
#
#  - Better Implementation:
#    - Up-Sweep
#    - $x_{0:1} = x_0 + x_1$, $x_{2:3} = x_2 + x_3$, $\ldots$, $x_{T-1:T} = x_{T_1} + x_t$
#    - x_{0:3} = x_{0:1} + x_{2:3}$, $\ldots$, $x_{T-3:T} = x_{T-3:T-2} + x_{T-1:T}$
#    - $\ldots$
#    - $x_{0:T} = x_{0:T/2} + x_{T/2+1:T}$
#
#<img src="./SequenceModels/parallel_scan_up_sweep.png" width="600"/>
#
#  - Down-Sweep
#    - Add 0 at end and percolate it through left half of tree
#    - Each level $k$ requires $T/2^{k-1}$ operations
#
#<img src="./SequenceModels/parallel_scan_down_sweep.png" width="600"/>

# %% [markdown]
### Parallel Scan for SSMs
#- For state space models, the scan operation is as follows:
#  - $(a, b) \circ (a’, b’) = (a a’,\ b + a b’)$
#  - $a = \Delta_t$, $b = B_t x_t$
#  - Easy to check that $\circ$ is associative
#
#<img src="./SequenceModels/ssm_scan_operation.png" width="600"/>
#
#  - Idea: We can use arbitrary matrices $B_t$, $C_t$ and $\Delta_t$ for different time points without breaking parallel scan!
#  - For efficiency use $A = Id$
#
#<img src="./SequenceModels/ssm_mamba_scan.png" width="600"/>
#

# %% [markdown]
## Mamba Architecture
#- [Mamba 1](https://arxiv.org/abs/2312.00752)
#- Head structure:
#
#<img src="./SequenceModels/ssm_multiple_dimensions.png" width="800"/>
#
#- We stack multiple blocks
#- Each block additionally uses (up/down)projection and convolution.
#  - Mamba 1 Block:
#
#<img src="./SequenceModels/ssm_mamba_block.png" width="600"/>
#

# %%
# Mamba V1 Implementation
# [Implementation ack](https://github.com/johnma2006/mamba-minimal/)
# Mamba block
from __future__ import annotations
import math
import json
import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from einops import rearrange, repeat, einsum

@dataclass
class ModelArgs:
    d_model: int
    n_layer: int
    vocab_size: int
    d_state: int = 16
    expand: int = 2
    dt_rank: Union[int, str] = 'auto' # for low-dimensional latent representation of $\Delta_t$
    d_conv: int = 4 
    pad_vocab_size_multiple: int = 8
    conv_bias: bool = True
    bias: bool = False
    
    def __post_init__(self):
        self.d_inner = int(self.expand * self.d_model)
        
        if self.dt_rank == 'auto':
            self.dt_rank = math.ceil(self.d_model / 16)
            
        if self.vocab_size % self.pad_vocab_size_multiple != 0:
            self.vocab_size += (self.pad_vocab_size_multiple
                                - self.vocab_size % self.pad_vocab_size_multiple)

class MambaBlock(nn.Module):
    def __init__(self, args: ModelArgs):
        super().__init__()
        self.args = args

        # for SSM and residual stream
        self.in_proj = nn.Linear(args.d_model, args.d_inner * 2, bias=args.bias)

        self.conv1d = nn.Conv1d(
            in_channels=args.d_inner,
            out_channels=args.d_inner,
            bias=args.conv_bias,
            kernel_size=args.d_conv,
            groups=args.d_inner,
            padding=args.d_conv - 1,
        )

        # x_proj takes in `x` and outputs the input-specific Δ, B, C
        self.x_proj = nn.Linear(args.d_inner, args.dt_rank + args.d_state * 2, bias=False)
        
        # dt_proj projects Δ from dt_rank to d_in
        self.dt_proj = nn.Linear(args.dt_rank, args.d_inner, bias=True)

        A = repeat(torch.arange(1, args.d_state + 1), 'n -> d n', d=args.d_inner)
        self.A_log = nn.Parameter(torch.log(A))
        self.D = nn.Parameter(torch.ones(args.d_inner))
        self.out_proj = nn.Linear(args.d_inner, args.d_model, bias=args.bias)
        

    def forward(self, x):
        """Mamba block forward. This looks the same as Figure 3 in Section 3.4 in the Mamba paper [1].
    
        Args:
            x: shape (b, l, d)    (See Glossary at top for definitions of b, l, d_in, n...)
    
        Returns:
            output: shape (b, l, d)
        
        Official Implementation:
            class Mamba, https://github.com/state-spaces/mamba/blob/main/mamba_ssm/modules/mamba_simple.py#L119
            mamba_inner_ref(), https://github.com/state-spaces/mamba/blob/main/mamba_ssm/ops/selective_scan_interface.py#L311
            
        """
        (b, l, d) = x.shape
        
        x_and_res = self.in_proj(x)  # shape (b, l, 2 * d_in)
        (x, res) = x_and_res.split(split_size=[self.args.d_inner, self.args.d_inner], dim=-1)

        x = rearrange(x, 'b l d_in -> b d_in l')
        x = self.conv1d(x)[:, :, :l]
        x = rearrange(x, 'b d_in l -> b l d_in')
        
        x = F.silu(x)

        y = self.ssm(x)
        
        y = y * F.silu(res)
        
        output = self.out_proj(y)

        return output

    
    def ssm(self, x):
        """Runs the SSM. See:
            - Algorithm 2 in Section 3.2 in the Mamba paper [1]
            - run_SSM(A, B, C, u) in The Annotated S4 [2]

        Args:
            x: shape (b, l, d_in)    (See Glossary at top for definitions of b, l, d_in, n...)
    
        Returns:
            output: shape (b, l, d_in)

        Official Implementation:
            mamba_inner_ref(), https://github.com/state-spaces/mamba/blob/main/mamba_ssm/ops/selective_scan_interface.py#L311
            
        """
        (d_in, n) = self.A_log.shape

        # Compute ∆ A B C D, the state space parameters.
        #     A, D are input independent (see Mamba paper [1] Section 3.5.2 "Interpretation of A" for why A isn't selective)
        #     ∆, B, C are input-dependent (this is a key difference between Mamba and the linear time invariant S4,
        #                                  and is why Mamba is called **selective** state spaces)
        
        A = -torch.exp(self.A_log.float())  # shape (d_in, n)
        D = self.D.float()

        x_dbl = self.x_proj(x)  # (b, l, dt_rank + 2*n)
        
        (delta, B, C) = x_dbl.split(split_size=[self.args.dt_rank, n, n], dim=-1)  # delta: (b, l, dt_rank). B, C: (b, l, n)
        delta = F.softplus(self.dt_proj(delta))  # (b, l, d_in)
        
        y = self.selective_scan(x, delta, A, B, C, D)
        
        return y

    
    def selective_scan(self, u, delta, A, B, C, D):
        """Does selective scan algorithm. See:
            - Section 2 State Space Models in the Mamba paper [1]
            - Algorithm 2 in Section 3.2 in the Mamba paper [1]
            - run_SSM(A, B, C, u) in The Annotated S4 [2]

        This is the classic discrete state space formula:
            x(t + 1) = Ax(t) + Bu(t)
            y(t)     = Cx(t) + Du(t)
        except B and C (and the step size delta, which is used for discretization) are dependent on the input x(t).
    
        Args:
            u: shape (b, l, d_in)    (See Glossary at top for definitions of b, l, d_in, n...)
            delta: shape (b, l, d_in)
            A: shape (d_in, n)
            B: shape (b, l, n)
            C: shape (b, l, n)
            D: shape (d_in,)
    
        Returns:
            output: shape (b, l, d_in)
    
        Official Implementation:
            selective_scan_ref(), https://github.com/state-spaces/mamba/blob/main/mamba_ssm/ops/selective_scan_interface.py#L86
            Note: I refactored some parts out of `selective_scan_ref` out, so the functionality doesn't match exactly.
            
        """
        (b, l, d_in) = u.shape
        n = A.shape[1]
        
        # Discretize continuous parameters (A, B)
        # - A is discretized using zero-order hold (ZOH) discretization (see Section 2 Equation 4 in the Mamba paper [1])
        # - B is discretized using a simplified Euler discretization instead of ZOH. From a discussion with authors:
        #   "A is the more important term and the performance doesn't change much with the simplification on B"
        deltaA = torch.exp(einsum(delta, A, 'b l d_in, d_in n -> b l d_in n'))
        deltaB_u = einsum(delta, B, u, 'b l d_in, b l n, b l d_in -> b l d_in n')
        
        # Perform selective scan (see scan_SSM() in The Annotated S4 [2])
        # Note that the below is sequential, while the official implementation does a much faster parallel scan that
        # is additionally hardware-aware (like FlashAttention).
        x = torch.zeros((b, d_in, n), device=deltaA.device)
        ys = []    
        for i in range(l):
            x = deltaA[:, i] * x + deltaB_u[:, i]
            y = einsum(x, C[:, i, :], 'b d_in n, b n -> b d_in')
            ys.append(y)
        y = torch.stack(ys, dim=1)  # shape (b, l, d_in)
        
        y = y + u * D
    
        return y

# %%
# Mamba overall
class RMSNorm(nn.Module):
    def __init__(self,
                 d_model: int,
                 eps: float = 1e-5):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(d_model))


    def forward(self, x):
        output = x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps) * self.weight

        return output

class Mamba(nn.Module):
    def __init__(self, args: ModelArgs):
        """Full Mamba model."""
        super().__init__()
        self.args = args
        
        self.embedding = nn.Embedding(args.vocab_size, args.d_model)
        self.layers = nn.ModuleList([
            nn.ModuleDict({
                'mixer': MambaBlock(args),
                'norm': RMSNorm(args.d_model)
                }) for _ in range(args.n_layer)
            ])
        self.norm_f = RMSNorm(args.d_model)

        self.lm_head = nn.Linear(args.d_model, args.vocab_size, bias=False)
        self.lm_head.weight = self.embedding.weight  # Tie output projection to embedding weights.
                                                     # See "Weight Tying" paper


    def forward(self, input_ids):
        """
        Args:
            input_ids (long tensor): shape (b, l)    (See Glossary at top for definitions of b, l, d_in, n...)
    
        Returns:
            logits: shape (b, l, vocab_size)

        Official Implementation:
            class MambaLMHeadModel, https://github.com/state-spaces/mamba/blob/main/mamba_ssm/models/mixer_seq_simple.py#L173

        """
        x = self.embedding(input_ids)
        
        for layer in self.layers:
            x = layer['mixer'](layer['norm'](x)) + x
            
        x = self.norm_f(x)
        logits = self.lm_head(x)

        return logits

    @staticmethod
    def from_pretrained(pretrained_model_name: str):
        """Load pretrained weights from HuggingFace into model.
    
        Args:
            pretrained_model_name: One of
                * 'state-spaces/mamba-2.8b-slimpj'
                * 'state-spaces/mamba-2.8b'
                * 'state-spaces/mamba-1.4b'
                * 'state-spaces/mamba-790m'
                * 'state-spaces/mamba-370m'
                * 'state-spaces/mamba-130m'
                            
        Returns:
            model: Mamba model with weights loaded
    
        """
        from transformers.utils import WEIGHTS_NAME, CONFIG_NAME
        from transformers.utils.hub import cached_file
        
        def load_config_hf(model_name):
            resolved_archive_file = cached_file(model_name, CONFIG_NAME,
                                                _raise_exceptions_for_missing_entries=False)
            return json.load(open(resolved_archive_file))
        
        
        def load_state_dict_hf(model_name, device=None, dtype=None):
            resolved_archive_file = cached_file(model_name, WEIGHTS_NAME,
                                                _raise_exceptions_for_missing_entries=False)
            return torch.load(resolved_archive_file, weights_only=True, map_location='cpu', mmap=True)
        
        config_data = load_config_hf(pretrained_model_name)
        args = ModelArgs(
            d_model=config_data['d_model'],
            n_layer=config_data['n_layer'],
            vocab_size=config_data['vocab_size']
        )
        model = Mamba(args)
        
        state_dict = load_state_dict_hf(pretrained_model_name)
        new_state_dict = {}
        for key in state_dict:
            new_key = key.replace('backbone.', '')
            new_state_dict[new_key] = state_dict[key]
        model.load_state_dict(new_state_dict)
        
        return model

# %%
# Load model from Huggingface and try out
from transformers import AutoTokenizer
if torch.cuda.is_available():
    device = torch.device('cuda')
elif torch.backends.mps.is_available():
    device = torch.device('mps')
else:
    device = torch.device('cpu')

from transformers import AutoTokenizer

# One of:
#     'state-spaces/mamba-2.8b-slimpj'
#     'state-spaces/mamba-2.8b'
#     'state-spaces/mamba-1.4b'
#     'state-spaces/mamba-790m'
#     'state-spaces/mamba-370m'
#     'state-spaces/mamba-130m'

def generate(model,
             tokenizer,
             prompt: str,
             n_tokens_to_gen: int = 50,
             sample: bool = True,
             top_k: int = 40):
    model.eval()
    
    input_ids = tokenizer(prompt, return_tensors='pt').input_ids
    
    for token_n in range(n_tokens_to_gen):
        with torch.no_grad():
            indices_to_input = input_ids
            next_token_logits = model(indices_to_input)[:, -1]
        
        probs = F.softmax(next_token_logits, dim=-1)
        (batch, vocab_size) = probs.shape
        
        if top_k is not None:
            (values, indices) = torch.topk(probs, k=top_k)
            probs[probs < values[:, -1, None]] = 0
            probs = probs / probs.sum(axis=1, keepdims=True)
        
        if sample:
            next_indices = torch.multinomial(probs, num_samples=1)
        else:
            next_indices = torch.argmax(probs, dim=-1)[:, None]
        
        input_ids = torch.cat([input_ids, next_indices], dim=1)

    output_completions = [tokenizer.decode(output.tolist()) for output in input_ids][0]
    
    return output_completions

if __name__ == '__main__':
    pretrained_model_name = 'state-spaces/mamba-2.8b'
    model = Mamba.from_pretrained(pretrained_model_name)
    tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neox-20b')
    print(generate(model, tokenizer, 'I, Donald Trump, pledge'))
    exit()

# %% [markdown]
### Training with parallel scan
#- In the above code, the forward code has been implemented recursively without the parallel scan
#- It turns out that parallel scan, while being able to saturate the GPU, is not particularly fast
#  - Parallel scan uses complicated memory access patterns
#  - Does not make use of fast tensor cores for matrix multiplication, which are significantly faster than regular cuda cores
#  - Due to this issue $N$ in Mamba v1 is only 16 (see parameter d_state in ModelArgs)
#- We will not dive into the complicated implementation of parallel scan, but jump directly to Mamba v2, which approaches SSMs using a different technique

# %% [markdown]
## Mamba v2 Intro
#- [Mamba 2](https://arxiv.org/abs/2405.21060)
#- [Blog post](https://tridao.me/blog/2024/mamba2-part1-model/)
#- Paper content:
#  - Faster way to compute SSM recursion in parallel
#  - A few minor modifications/simplifications to Mamba block to help with faster computation
#
#### State Space Duality (SSD)
#- In a nutshell:
#  - There exist a connection between SSMs and attention as matrix multiplication
#  - Parallel SSM computation during training can be accelerated by recasting it as matrix multiplication
#
#- Preliminaries:
#  - Recall SSM model: 
#$h_t = A_t h_{t-1} + B_t x_t$ (note abuse of notation with $\bar{A}$ and $\bar{B})\quad y_t = C_t^\top h_t$
#  - $x \in \R^T \mapsto y \in \R^T$
#  - $h \in \R^{T \times N}$
#  - In Mamba v2 $A_t$ is a scalar times identity, hence we can express it via one scalar and we can write $A \in R^T$
#    - Sometimes we denote $A_t$ by $a_t \in \R$
#    - Mamba v2 is a more restricted model. However, we will be able to have larger $N = 64$ or $N = 128$ than in Mamba v1, which will make up for it.
#- Define the matrices
#$$ L = \begin{bmatrix}
#1 & & & & \\
#a_1 & 1 & & & \\
#a_2 a_1 & a_2 & 1 & & \\
#\vdots & \vdots & \ddots & \ddots & \\
#a_{T-1}\cdots a_1 & a_{T-1}\cdots a_2 & \cdots & a_{T-1} & 1
#\end{bmatrix}
#$$
#  - Define $a_{i:j+1} = a_i \cdots a_j$. We can write $L$ as
#$$ L = \begin{bmatrix}
#a_{1:1} & & & & \\
#a_{1:2} & a_{2:2} & & & \\
#a_{1:3} & a_{2:3} & a_{3:3} & & \\
#\vdots & \vdots & \ddots & \ddots & \\
#a_{1:T} & a_{2:T} & \cdots & a_{T-1:T} & a_{T:T}
#\end{bmatrix}
#$$
#  - State space model can be written in matrix form as: 
#$$M = L \circ CB^\top X$$
#    - Note that we can draw out $L$ due to $A$ being a scalar times identity
#  - Compare to causal linear attention:
#$$ Y = (L \circ QK^\top) V$$
#
#    - Same as causal attention, but softmax is dropped (Let us suppress multiplication with $\frac{1}{\sqrt{d}}$ for simplicity)
#  - SSM and causal linear attention are the same if:
#    - $a_i = 1$ for all $i$
#    - $(C,B,X) \mapsto (Q,K,V)$
#- Idea: Instantiate matrix $M$ and use matrix multiplication to compute SSM
#  - Can use fast tensor cores for matmul
#  - But is quadratic in sequence length and will eventually blow up
#  - Also, if we already use quadratic inference we can directly go with (better) vanilla causal attention.
#- Better idea: We can use special structure of matrix $M$ and still use matmul in block-wise fashion
#
#|                     | **Attention** | **SSM** | **SSD** |
#|---------------------|---------------|---------|---------|
#| **State size**      | T             | N       | N       |
#| **Training FLOPs**  | T²N           | TN²     | TN²     |
#| **Inference FLOPs** | TN            | N²      | N²      |
#| **(Naive) memory**  | T²            | TN²     | TN      |
#| **Matrix multiplications?*| ✅      | ❌      | ✅      |


# %% [markdown]
## Mamba v2 Algorithm for SSM
#
#<img src="./SequenceModels/ssm_mambav2_semiseparable_matrix.png" width="800"/>
#
#- The special structure of matrix $M$ is known as a semiseparable matrix
#- Partition $M$ into block of size $Q \times Q$ 
#  - $Q = 3$ in the image
#- Orange: Each diagonal block is a small semiseparable matrix
#  - Compute it by explicitly instantiating and using matmul
#- Green: There are only $T/Q$ different green blocks
#  - Compute with batched matmul
#- Yellow: Can be computed by parallel scan
#  - Or directly, since we only have scalars here, this operation is cheap overall
#- Blue: As for green, there are only $T/Q$ of them
#  - Compute with batched matmul
#- Interpretation of algorithm
#  - **Intra-chunk outputs**: compute the local output of each chunk (what is the output per chunk supposing that the initial state (to the chunk) is 0?)
### Computing Low-Rank Blocks (lower tridiagonal)
#- Right factors: Multiply with $\begin{bmatrix} B_0^\top A_{2:0} \\ B_1^\top A_{2:1} B_{2}^\top A_{2:2} \end{bmatrix}$  and subsequent blocks:
#  - For each chunk this is $N \times Q$ by $Q \times P$ multiplication
#  - Results in $N \times P$ matrix for each chunk
#- Center factors: Multiply with 1-SS matrix $A_{2Q-1:Q-1}$, $A_{3Q-1:2Q-1}$, ..., $A_{T-1:T-Q-1}$
#  - Can be computed by parallel scan or just explicitly
#  - Note that this matrix size is divided by $Q$
#- Left factors:
#$\begin{bmatrix}
# C_3^\top A_{3:2} \\ C_4^\top A_{4:2} \\ C_5^\top A_{5:2} 
#\end{bmatrix}$
#  - Can be represented by matmul

# %% [markdown]
#### Tensor contraction view
#- $M$ can be computed using matrix multiplication as:
#$$\begin{aligned}
#G &= \operatorname{einsum}(\mathrm{TN}, \mathrm{SN} \to \mathrm{TS})(C, B) \\
#M &= \operatorname{einsum}(\mathrm{TS}, \mathrm{TS} \to \mathrm{TS})(G, L) \\
#Y &= \operatorname{einsum}(\mathrm{TS}, \mathrm{SP} \to \mathrm{TP})(M, X)
#\end{aligned}$$
#- Alternatively, one can see that this is the same as a single-way einsum:
#$$ y = \operatorname{einsum}(\mathrm{TN}, \mathrm{SN}, \mathrm{SP}, \mathrm{TS} \to \mathrm{TP})(C, B, X, L)$$
#- We can also rearrange with any other contraction ordering:
#$$\begin{aligned}
#Z &= \operatorname{einsum}(\mathrm{SP}, \mathrm{SN} \to \mathrm{SPN})(X, B) \\
#H &= \operatorname{einsum}(\mathrm{TS}, \mathrm{SPN} \to \mathrm{TPN})(L, Z) \\
#Y &= \operatorname{einsum}(\mathrm{TN}, \mathrm{TPN} \to \mathrm{TP})(C, H)
#\end{aligned}$$

# %%
# SSD implementation
def segsum(x):
    """Naive segment sum calculation. exp(segsum(A)) produces a 1-SS matrix,
       which is equivalent to a scalar SSM."""
    T = x.size(-1)
    x_cumsum = torch.cumsum(x, dim=-1)
    x_segsum = x_cumsum[..., :, None] - x_cumsum[..., None, :]
    mask = torch.tril(torch.ones(T, T, device=x.device, dtype=bool), diagonal=0)
    x_segsum = x_segsum.masked_fill(~mask, -torch.inf)
    return x_segsum

def ssd(X, A, B, C, block_len=64, initial_states=None):
    """
    Arguments:
        X: (batch, length, n_heads, d_head)
        A: (batch, length, n_heads)
        B: (batch, length, n_heads, d_state)
        C: (batch, length, n_heads, d_state)
    Return:
        Y: (batch, length, n_heads, d_head)
    """
    assert X.dtype == A.dtype == B.dtype == C.dtype
    assert X.shape[1] % block_len == 0

    # Rearrange into blocks/chunks
    X, A, B, C = [rearrange(x, "b (c l) ... -> b c l ...", l=block_len) for x in (X, A, B, C)]

    A = rearrange(A, "b c l h -> b h c l")
    A_cumsum = torch.cumsum(A, dim=-1)

    # 1. Compute the output for each intra-chunk (diagonal blocks)
    L = torch.exp(segsum(A))
    Y_diag  = torch.einsum("bclhn,bcshn,bhcls,bcshp->bclhp", C, B, L, X)

    # 2. Compute the state for each intra-chunk
    # (right term of low-rank factorization of off-diagonal blocks; B terms)
    decay_states = torch.exp((A_cumsum[:, :, :, -1:] - A_cumsum))
    states = torch.einsum("bclhn,bhcl,bclhp->bchpn", B, decay_states, X)

    # 3. Compute the inter-chunk SSM recurrence; produces correct SSM states at chunk boundaries
    # (middle term of factorization of off-diag blocks; A terms)
    if initial_states is None:
        initial_states = torch.zeros_like(states[:, :1])
    states = torch.cat([initial_states, states], dim=1)
    decay_chunk = torch.exp(segsum(F.pad(A_cumsum[:, :, :, -1], (1, 0)))) # pad from left to account for initial state
    new_states = torch.einsum("bhzc,bchpn->bzhpn", decay_chunk, states)
    states, final_state = new_states[:, :-1], new_states[:, -1]

    # 4. Compute state -> output conversion per chunk
    # (left term of low-rank factorization of off-diagonal blocks; C terms)
    state_decay_out = torch.exp(A_cumsum)
    Y_off = torch.einsum('bclhn,bchpn,bhcl->bclhp', C, states, state_decay_out)

    # Add output of intra-chunk and inter-chunk terms (diagonal and off-diagonal blocks)
    Y = rearrange(Y_diag+Y_off, "b c l h p -> b (c l) h p")
    return Y, final_state

# %%
# Test SSD implementation
def test_ssd():
    batch_size = 2
    length = 256
    n_heads = 4
    d_head = 8
    d_state = 16

    X = torch.randn(batch_size, length, n_heads, d_head)
    A = torch.randn(batch_size, length, n_heads)
    B = torch.randn(batch_size, length, n_heads, d_state)
    C = torch.randn(batch_size, length, n_heads, d_state)

    Y, final_state = ssd(X, A, B, C)


if __name__ == "__main__":
    test_ssd()

# %% [markdown]
### Mamba v2 Architecture
###### (Parallel) Mamba v2 block:
#- Simplification of (Sequential) Mamba v1 block
#- Removes linear projections 
#- Additional normalization for better training stability
#
#<img src="./SequenceModels/ssm_mamba1_vs_mamba2_block.png" width="600"/>
#

# %%
# Implementation from https://github.com/tommyip/mamba2-minimal/tree/main

import json
from dataclasses import dataclass
from typing import Iterable, NamedTuple, TypeAlias, cast

import torch
import torch.nn.functional as F
from einops import rearrange, repeat
from torch import LongTensor, Tensor, nn

Device: TypeAlias = str | torch.device | None


@dataclass
class Mamba2Config:
    d_model: int  # model dimension (D)
    n_layer: int = 24  # number of Mamba-2 layers in the language model
    d_state: int = 128  # state dimension (N)
    d_conv: int = 4  # convolution kernel size
    expand: int = 2  # expansion factor (E)
    headdim: int = 64  # head dimension (P)
    chunk_size: int = 64  # matrix partition size (Q)
    vocab_size: int = 50277
    pad_vocab_size_multiple: int = 16

    def __post_init__(self):
        self.d_inner = self.expand * self.d_model
        assert self.d_inner % self.headdim == 0
        self.nheads = self.d_inner // self.headdim
        if self.vocab_size % self.pad_vocab_size_multiple != 0:
            self.vocab_size += (
                self.pad_vocab_size_multiple
                - self.vocab_size % self.pad_vocab_size_multiple
            )


class InferenceCache(NamedTuple):
    conv_state: Tensor  # (batch, d_inner + 2 * d_state, d_conv)
    ssm_state: Tensor  # (batch, nheads, headdim, d_state)

    @staticmethod
    def alloc(batch_size: int, args: Mamba2Config, device: Device = None):
        return InferenceCache(
            torch.zeros(
                batch_size, args.d_inner + 2 * args.d_state, args.d_conv, device=device
            ),
            torch.zeros(
                batch_size, args.nheads, args.headdim, args.d_state, device=device
            ),
        )


class Mamba2LMHeadModel(nn.Module):
    def __init__(self, args: Mamba2Config, device: Device = None):
        super().__init__()
        self.args = args
        self.device = device

        self.backbone = nn.ModuleDict(
            dict(
                embedding=nn.Embedding(args.vocab_size, args.d_model, device=device),
                layers=nn.ModuleList(
                    [
                        nn.ModuleDict(
                            dict(
                                mixer=Mamba2(args, device=device),
                                norm=RMSNorm(args.d_model, device=device),
                            )
                        )
                        for _ in range(args.n_layer)
                    ]
                ),
                norm_f=RMSNorm(args.d_model, device=device),
            )
        )
        self.lm_head = nn.Linear(
            args.d_model, args.vocab_size, bias=False, device=device
        )
        self.lm_head.weight = self.backbone.embedding.weight

    @staticmethod
    def from_pretrained(huggingface_model_id: str, device: Device = None):
        from transformers.utils import CONFIG_NAME, WEIGHTS_NAME
        from transformers.utils.hub import cached_file

        config_path = cached_file(huggingface_model_id, CONFIG_NAME)
        assert config_path, "Failed to get huggingface config file"
        state_dict_path = cached_file(huggingface_model_id, WEIGHTS_NAME)
        assert state_dict_path, "Failed to get huggingface state dict file"

        config = json.load(open(config_path))
        args = Mamba2Config(
            d_model=config["d_model"],
            n_layer=config["n_layer"],
            vocab_size=config["vocab_size"],
            pad_vocab_size_multiple=config["pad_vocab_size_multiple"],
        )

        map_location = "cpu" if device is None else device
        state_dict = torch.load(
            state_dict_path, weights_only=True, map_location=map_location, mmap=True
        )
        model = Mamba2LMHeadModel(args, device=device)
        model.load_state_dict(state_dict)
        model.eval()
        return model

    def forward(
        self, input_ids: LongTensor, h: list[InferenceCache] | list[None] | None = None
    ) -> tuple[LongTensor, list[InferenceCache]]:
        """
        Arguments
            input_ids: (batch, seqlen) tokens from `EleutherAI/gpt-neox-20b` tokenizer
            h: hidden states for inference step. If present the constant-time
               (wrt sequence length) inference path will be taken, input_ids
               should have shape (batch, 1) containing the next batch of prompt
               token.

        Return (logits, h)
            logits: (batch, seqlen, vocab_size)
            h: updated inference cache after processing `input_ids`
        """
        seqlen = input_ids.shape[1]

        if h is None:
            h = [None for _ in range(self.args.n_layer)]

        x = self.backbone.embedding(input_ids)
        for i, layer in enumerate(self.backbone.layers):
            y, h[i] = layer.mixer(layer.norm(x), h[i])
            x = y + x

        x = self.backbone.norm_f(x)
        logits = self.lm_head(x)
        return logits[:, :seqlen], cast(list[InferenceCache], h)

    def generate(
        self,
        input_ids: LongTensor,
        max_new_length: int = 20,
        temperature: float = 1.0,
        top_k: int = 50,
        top_p: float = 1.0,
        eos_token_id: int = 0,
    ) -> Iterable[tuple[int, list[InferenceCache]]]:
        prefix, tokens = input_ids[:-1], input_ids[-1:].unsqueeze(0)

        # Process prompt
        # The input sequence to forward (non-inference path) must have length multiple that of chunk_size.
        # We split out excess tokens so that n_chunked tokens can be processed by one forward call and
        # process the rest in multiple inference steps.
        n_chunked = (prefix.shape[0] // self.args.chunk_size) * self.args.chunk_size
        if n_chunked > 0:
            _, h = self(prefix[:n_chunked].unsqueeze(0), None)
        else:
            h = [
                InferenceCache.alloc(1, self.args, device=self.device)
                for _ in range(self.args.n_layer)
            ]
        for i in range(n_chunked, prefix.shape[0]):
            _, h = self(prefix[i : i + 1].unsqueeze(0), h)

        # Generate
        for _ in range(max_new_length):
            with torch.no_grad():
                out, h = self(tokens, h)
            logits = out[0, -1]
            if temperature != 1.0:
                logits = logits / temperature
            if top_k > 0:
                indices_to_remove = logits < torch.topk(logits, k=top_k)[0][-1]
                logits[indices_to_remove] = -torch.inf
            if top_p < 1.0:
                sorted_logits, sorted_indices = torch.sort(logits, descending=True)
                cum_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
                sorted_indices_to_remove = cum_probs > 0.5
                sorted_indices_to_remove[1:] = sorted_indices_to_remove[:-1].clone()
                sorted_indices_to_remove[0] = False
                indices_to_remove = sorted_indices[sorted_indices_to_remove]
                logits[indices_to_remove] = -torch.inf
            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            if next_token.item() == eos_token_id:
                return
            tokens = next_token.unsqueeze(0)
            yield cast(int, next_token.item()), h


class Mamba2(nn.Module):
    def __init__(self, args: Mamba2Config, device: Device = None):
        super().__init__()
        self.args = args
        self.device = device

        # Order: (z, x, B, C, dt)
        d_in_proj = 2 * args.d_inner + 2 * args.d_state + args.nheads
        self.in_proj = nn.Linear(args.d_model, d_in_proj, bias=False, device=device)

        conv_dim = args.d_inner + 2 * args.d_state
        self.conv1d = nn.Conv1d(
            in_channels=conv_dim,
            out_channels=conv_dim,
            kernel_size=args.d_conv,
            groups=conv_dim,
            padding=args.d_conv - 1,
            device=device,
        )

        self.dt_bias = nn.Parameter(torch.empty(args.nheads, device=device))
        self.A_log = nn.Parameter(torch.empty(args.nheads, device=device))
        self.D = nn.Parameter(torch.empty(args.nheads, device=device))
        self.norm = RMSNorm(args.d_inner, device=device)
        self.out_proj = nn.Linear(args.d_inner, args.d_model, bias=False, device=device)

    def forward(self, u: Tensor, h: InferenceCache | None = None):
        """
        Arguments
            u: (batch, seqlen, d_model) input. seqlen should be a multiple of chunk_size.
            h: hidden states for inference step. Initialized to 0s if not present.

        Return (y, h)
            y: (batch, seqlen, d_model) output
            h: updated inference cache after processing `u`
        """
        if h:
            return self.step(u, h)

        A = -torch.exp(self.A_log)  # (nheads,)
        zxbcdt = self.in_proj(u)  # (batch, seqlen, d_in_proj)
        z, xBC, dt = torch.split(
            zxbcdt,
            [
                self.args.d_inner,
                self.args.d_inner + 2 * self.args.d_state,
                self.args.nheads,
            ],
            dim=-1,
        )
        dt = F.softplus(dt + self.dt_bias)  # (batch, seqlen, nheads)

        # Pad or truncate xBC seqlen to d_conv
        conv_state = F.pad(
            rearrange(xBC, "b l d -> b d l"), (self.args.d_conv - u.shape[1], 0)
        )

        xBC = silu(
            self.conv1d(xBC.transpose(1, 2)).transpose(1, 2)[:, : u.shape[1], :]
        )  # (batch, seqlen, d_inner + 2 * d_state))
        x, B, C = torch.split(
            xBC, [self.args.d_inner, self.args.d_state, self.args.d_state], dim=-1
        )
        x = rearrange(x, "b l (h p) -> b l h p", p=self.args.headdim)
        y, ssm_state = ssd(
            x * dt.unsqueeze(-1),
            A * dt,
            rearrange(B, "b l n -> b l 1 n"),
            rearrange(C, "b l n -> b l 1 n"),
            self.args.chunk_size,
            device=self.device,
        )
        y = y + x * self.D.unsqueeze(-1)
        y = rearrange(y, "b l h p -> b l (h p)")
        y = self.norm(y, z)
        y = self.out_proj(y)

        h = InferenceCache(conv_state, ssm_state)
        return y, h

    def step(self, u: Tensor, h: InferenceCache) -> tuple[Tensor, InferenceCache]:
        """Take a single inference step for the current input and hidden state

        Unlike attention-based models, RNN-based models (eg Mamba) does not need
        to look back at all the past tokens to generate a new token. Instead a
        hidden state (initialized to 0s initially) is updated for each input and
        passed to the next inference step. This means that the total inference
        time is linear with respect to the sequence length instead of quadratic
        in attention's case.

        Arguments
            u: (batch, 1, d_model)
            h: initial/running hidden state

        Return (y, h)
            y: (batch, 1, d_model)
            h: updated hidden state
        """
        assert u.shape[1] == 1, "Only one token can be decoded per inference step"

        zxbcdt = self.in_proj(u.squeeze(1))  # (batch, d_in_proj)
        z, xBC, dt = torch.split(
            zxbcdt,
            [
                self.args.d_inner,
                self.args.d_inner + 2 * self.args.d_state,
                self.args.nheads,
            ],
            dim=-1,
        )

        # Advance convolution input
        h.conv_state.copy_(torch.roll(h.conv_state, shifts=-1, dims=-1))
        h.conv_state[:, :, -1] = xBC
        # Convolution step
        xBC = torch.sum(
            h.conv_state * rearrange(self.conv1d.weight, "d 1 w -> d w"), dim=-1
        )
        xBC += self.conv1d.bias
        xBC = silu(xBC)

        x, B, C = torch.split(
            xBC, [self.args.d_inner, self.args.d_state, self.args.d_state], dim=-1
        )
        A = -torch.exp(self.A_log)  # (nheads,)

        # SSM step
        dt = F.softplus(dt + self.dt_bias)  # (batch, nheads)
        dA = torch.exp(dt * A)  # (batch, nheads)
        x = rearrange(x, "b (h p) -> b h p", p=self.args.headdim)
        dBx = torch.einsum("bh, bn, bhp -> bhpn", dt, B, x)
        h.ssm_state.copy_(h.ssm_state * rearrange(dA, "b h -> b h 1 1") + dBx)
        y = torch.einsum("bhpn, bn -> bhp", h.ssm_state, C)
        y = y + rearrange(self.D, "h -> h 1") * x
        y = rearrange(y, "b h p -> b (h p)")
        y = self.norm(y, z)
        y = self.out_proj(y)

        return y.unsqueeze(1), h


def segsum(x: Tensor, device: Device = None) -> Tensor:
    """Stable segment sum calculation.

    `exp(segsum(A))` produces a 1-semiseparable matrix, which is equivalent to a scalar SSM.

    Source: https://github.com/state-spaces/mamba/blob/219f03c840d5a44e7d42e4e728134834fddccf45/mamba_ssm/modules/ssd_minimal.py#L23-L32
    """
    T = x.size(-1)
    x = repeat(x, "... d -> ... d e", e=T)
    mask = torch.tril(torch.ones(T, T, dtype=torch.bool, device=device), diagonal=-1)
    x = x.masked_fill(~mask, 0)
    x_segsum = torch.cumsum(x, dim=-2)
    mask = torch.tril(torch.ones(T, T, dtype=torch.bool, device=device), diagonal=0)
    x_segsum = x_segsum.masked_fill(~mask, -torch.inf)
    return x_segsum


def ssd(x, A, B, C, chunk_size, initial_states=None, device: Device = None):
    """Structed State Space Duality (SSD) - the core of Mamba-2

    This is almost the exact same minimal SSD code from the blog post.

    Arguments
        x: (batch, seqlen, n_heads, d_head)
        A: (batch, seqlen, n_heads)
        B: (batch, seqlen, n_heads, d_state)
        C: (batch, seqlen, n_heads, d_state)

    Return
        y: (batch, seqlen, n_heads, d_head)

    Source
     1. https://tridao.me/blog/2024/mamba2-part3-algorithm/
     2. https://github.com/state-spaces/mamba/blob/219f03c840d5a44e7d42e4e728134834fddccf45/mamba_ssm/modules/ssd_minimal.py#L34-L78
    """
    assert x.shape[1] % chunk_size == 0

    # Rearrange into chunks
    x, A, B, C = [
        rearrange(m, "b (c l) ... -> b c l ...", l=chunk_size) for m in (x, A, B, C)
    ]

    A = rearrange(A, "b c l h -> b h c l")
    A_cumsum = torch.cumsum(A, dim=-1)

    # 1. Compute the output for each intra-chunk (diagonal blocks)
    L = torch.exp(segsum(A, device=device))
    Y_diag = torch.einsum("bclhn, bcshn, bhcls, bcshp -> bclhp", C, B, L, x)

    # 2. Compute the state for each intra-chunk
    # (right term of low-rank factorization of off-diagonal blocks; B terms)
    decay_states = torch.exp(A_cumsum[:, :, :, -1:] - A_cumsum)
    states = torch.einsum("bclhn, bhcl, bclhp -> bchpn", B, decay_states, x)

    # 3. Compute the inter-chunk SSM recurrence; produces correct SSM states at chunk boundaries
    # (middle term of factorization of off-diag blocks; A terms)
    if initial_states is None:
        initial_states = torch.zeros_like(states[:, :1])
    states = torch.cat([initial_states, states], dim=1)
    decay_chunk = torch.exp(segsum(F.pad(A_cumsum[:, :, :, -1], (1, 0)), device=device))
    new_states = torch.einsum("bhzc, bchpn -> bzhpn", decay_chunk, states)
    states, final_state = new_states[:, :-1], new_states[:, -1]

    # 4. Compute state -> output conversion per chunk
    # (left term of low-rank factorization of off-diagonal blocks; C terms)
    state_decay_out = torch.exp(A_cumsum)
    Y_off = torch.einsum("bclhn, bchpn, bhcl -> bclhp", C, states, state_decay_out)

    # Add output of intra-chunk and inter-chunk terms (diagonal and off-diagonal blocks)
    Y = rearrange(Y_diag + Y_off, "b c l h p -> b (c l) h p")

    return Y, final_state


class RMSNorm(nn.Module):
    def __init__(self, d: int, eps: float = 1e-5, device: Device = None):
        """Gated Root Mean Square Layer Normalization

        Paper: https://arxiv.org/abs/1910.07467
        """
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(d, device=device))

    def forward(self, x, z=None):
        if z is not None:
            x = x * silu(z)
        return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps) * self.weight


def silu(x):
    """Applies the Sigmoid Linear Unit (SiLU), element-wise.

    Define this manually since torch's version doesn't seem to work on MPS.
    """
    return x * F.sigmoid(x)

# %%
# Run Mambav2
import time

if __name__ == "__main__":
    # model can be from
    # state-spaces/mamba2-130m
    # state-spaces/mamba2-370m
    # state-spaces/mamba2-780m
    # state-spaces/mamba2-1.3b
    # state-spaces/mamba2-2.7b
    model = Mamba2LMHeadModel.from_pretrained("state-spaces/mamba2-1.3b", device=device)
    tokenizer = AutoTokenizer.from_pretrained("EleutherAI/gpt-neox-20b")
    tokenizer.pad_token_id = tokenizer.eos_token_id

    generation_config = dict(
        max_new_length=200,
        temperature=1.0,
        top_k=30,
        top_p=1.0,
    )

    def generate(prompt: str, seed: int = 0, show_perf: bool = True):
        """Generate streaming completion"""
        torch.manual_seed(seed)

        input_ids = tokenizer(prompt, return_tensors='pt').input_ids.to(device)[0]
        print(prompt, end="")

        start = time.process_time()
        n_generated = 0
        for i, (token_id, _hidden_state) in enumerate(model.generate(input_ids, **generation_config)):
            token = tokenizer.decode([token_id])
            if i == 0:
                now = time.process_time()
                prompt_eval_elapsed, start = now - start, now
            else:
                n_generated += 1
            print(token, end="", flush=True)
        if show_perf:
            elapsed = time.process_time() - start
            print('\n\n---')
            print(f'Prompt eval | tokens: {input_ids.shape[0]} | elapsed: {prompt_eval_elapsed:.2f}s | tok/s: {input_ids.shape[0] / prompt_eval_elapsed:.2f}')
            print(f'Generation | tokens: {n_generated} | elapsed: {elapsed:.2f}s | tok/s: {n_generated / elapsed:.2f}') 

    generate("I am Donald Trump and I pledge")
